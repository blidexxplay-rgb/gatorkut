
# Gatorkut

Gatorkut is a playful Orkut-inspired social network themed around cats.

## Structure

- frontend/  -> React + Vite + Tailwind (client)
- backend/   -> Node.js + Express + SQLite (API)

## Quick start (frontend local dev)

1. Enter `frontend` and run:
   - `npm install`
   - `npm run dev`
2. Open `http://localhost:5173`

## Quick start (backend)

1. Enter `backend` and run:
   - `npm install`
   - `node server.js`
2. API will be available on `http://localhost:3000`

## Docker (backend)
Build: `docker build -t gatorkut-backend .`
Run: `docker run -p 3000:3000 gatorkut-backend`

## Deploy to GitHub
1. Create a new GitHub repo.
2. Push the contents of this folder (`git init`, `git add .`, `git commit -m "initial"`, `git remote add origin ...`, `git push -u origin main`).

Enjoy! 🐾
