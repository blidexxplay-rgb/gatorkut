const express = require('express');
const Database = require('better-sqlite3');
const bodyParser = require('body-parser');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const SECRET = process.env.JWT_SECRET || 'dev-secret';

const db = new Database('./db.sqlite');
db.exec(`CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, displayName TEXT, about TEXT);
CREATE TABLE IF NOT EXISTS posts (id INTEGER PRIMARY KEY, author TEXT, text TEXT, image TEXT, time INTEGER, likes INTEGER DEFAULT 0, meows INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS comments (id INTEGER PRIMARY KEY, postId INTEGER, author TEXT, text TEXT, time INTEGER);
CREATE TABLE IF NOT EXISTS friends (id INTEGER PRIMARY KEY, userA TEXT, userB TEXT, status TEXT);
`);

const app = express();
app.use(cors());
app.use(bodyParser.json({limit:'10mb'}));

app.post('/auth/register', (req,res)=>{
  const {username, displayName} = req.body;
  if(!username) return res.status(400).send({error:'username'});
  try{
    const stmt = db.prepare('INSERT INTO users (username, displayName) VALUES (?,?)');
    stmt.run(username, displayName||username);
    res.send({ok:true});
  }catch(e){
    res.status(400).send({error:'exists'});
  }
});

app.post('/auth/login', (req,res)=>{
  const {username} = req.body;
  const u = db.prepare('SELECT username,displayName,about FROM users WHERE username=?').get(username);
  if(!u) return res.status(404).send({error:'notfound'});
  const token = jwt.sign({username}, SECRET, {expiresIn:'7d'});
  res.send({token, user:u});
});

function auth(req,res,next){
  const h = req.headers.authorization;
  if(!h) return res.status(401).send({error:'no token'});
  const token = h.split(' ')[1];
  try{
    const data = jwt.verify(token, SECRET);
    req.user = data;
    next();
  }catch(e){
    res.status(401).send({error:'invalid'});
  }
}

app.get('/posts', (req,res)=>{
  const rows = db.prepare('SELECT * FROM posts ORDER BY time DESC').all();
  res.send(rows);
});

app.post('/posts', auth, (req,res)=>{
  const {text,image} = req.body;
  const time = Date.now();
  const stmt = db.prepare('INSERT INTO posts (author,text,image,time,likes,meows) VALUES (?,?,?,?,0,0)');
  const info = stmt.run(req.user.username,text,image,time);
  res.send({id:info.lastInsertRowid});
});

app.post('/posts/:id/comments', auth, (req,res)=>{
  const postId = req.params.id;
  const {text} = req.body;
  const time = Date.now();
  const stmt = db.prepare('INSERT INTO comments (postId,author,text,time) VALUES (?,?,?,?)');
  stmt.run(postId, req.user.username, text, time);
  res.send({ok:true});
});

app.get('/users', (req,res)=>{
  const rows = db.prepare('SELECT username,displayName,about FROM users').all();
  res.send(rows);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=>console.log('Gatorkut API listening on',PORT));