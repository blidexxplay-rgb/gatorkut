import React, {useEffect, useState} from 'react'
import axios from 'axios'

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:3000'

function Header({session, onLogout, onSearch}) {
  return (
    <header className="bg-white shadow p-4 flex items-center gap-4 sticky top-0 z-20">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-coral to-purple flex items-center justify-center text-white font-bold">🐾</div>
        <div>
          <div className="font-extrabold">Gatorkut</div>
          <div className="text-sm text-gray-500">Orkut dos Gatos</div>
        </div>
      </div>
      <div className="ml-auto flex items-center gap-2">
        <input id="q" placeholder="Buscar usuários..." className="border rounded-full px-3 py-1 w-64" />
        <button className="bg-coral text-white px-3 py-1 rounded-full" onClick={() => onSearch(document.getElementById('q').value)}>Buscar</button>
        {session ? <button className="bg-red-500 text-white px-3 py-1 rounded-full" onClick={onLogout}>Sair</button> : null}
      </div>
    </header>
  )
}

function App(){
  const [db,setDb] = useState(null)
  const [session,setSession] = useState(null)
  const [posts,setPosts] = useState([])

  useEffect(()=>{
    // load local sample DB if no backend
    const raw = localStorage.getItem('gatorkut_db_v1')
    if(raw){
      const parsed = JSON.parse(raw)
      setDb(parsed)
      setPosts((parsed.posts||[]).slice().sort((a,b)=>b.time-a.time))
    } else {
      // seed
      const seed = { users:{ ana:{username:'ana',displayName:'Ana Gata',about:'Ama miar'}, joao:{username:'joao',displayName:'João Cat',about:'Fotógrafo de gatos'}}, posts:[], nextPostId:1, communities:[]}
      localStorage.setItem('gatorkut_db_v1', JSON.stringify(seed))
      setDb(seed)
      setPosts([])
    }
    const s = localStorage.getItem('gatorkut_session_v1')
    if(s) setSession(JSON.parse(s))
  },[])

  function login(u,d){
    const db2 = {...db}
    db2.users = db2.users||{}
    if(!db2.users[u]) db2.users[u] = {username:u,displayName:d||u,about:'',friends:[]}
    localStorage.setItem('gatorkut_db_v1', JSON.stringify(db2))
    localStorage.setItem('gatorkut_session_v1', JSON.stringify({username:u}))
    setDb(db2)
    setSession({username:u})
    setPosts((db2.posts||[]).slice().sort((a,b)=>b.time-a.time))
  }

  function logout(){
    localStorage.removeItem('gatorkut_session_v1')
    setSession(null)
  }

  function createPost(text,imageData){
    const db2 = {...db}
    db2.posts = db2.posts||[]
    const id = db2.nextPostId || 1
    db2.posts.unshift({id,author:session.username,text, time: Date.now(), likes:0, meows:0, comments:[], image:imageData||null})
    db2.nextPostId = id+1
    localStorage.setItem('gatorkut_db_v1', JSON.stringify(db2))
    setDb(db2)
    setPosts((db2.posts||[]).slice().sort((a,b)=>b.time-a.time))
  }

  return (
    <div className="min-h-screen bg-gatorkutBg">
      <Header session={session} onLogout={logout} onSearch={(q)=>alert('Buscar: '+q)} />
      <main className="max-w-6xl mx-auto grid grid-cols-12 gap-6 p-6">
        <aside className="col-span-3">
          <div className="bg-white shadow rounded-xl p-4">
            {!session ? (
              <Login onLogin={login} />
            ) : (
              <Profile username={session.username} db={db} />
            )}
          </div>
        </aside>
        <section className="col-span-6">
          <div className="bg-white shadow rounded-xl p-4 mb-4">
            {session ? <Composer onPost={createPost} /> : <div className="text-gray-500">Entre para publicar fotos do seu gato</div>}
          </div>
          <div>
            {posts.map(p => <Post key={p.id} post={p} db={db} />)}
          </div>
        </section>
        <aside className="col-span-3 space-y-4">
          <div className="bg-white shadow rounded-xl p-4">
            <h3 className="font-bold">Comunidades</h3>
            <div className="text-sm text-gray-600">Em breve: comunidades de gataria</div>
          </div>
          <div className="bg-white shadow rounded-xl p-4">
            <h3 className="font-bold">Amigos</h3>
            <div className="text-sm text-gray-600">Lista de amigos aparecerá aqui</div>
          </div>
        </aside>
      </main>
    </div>
  )
}

function Login({onLogin}){
  const [u,setU]=useState(''); const [d,setD]=useState('');
  return (
    <div>
      <h3 className="font-bold mb-2">Entrar / Criar</h3>
      <input className="w-full border rounded p-2 mb-2" placeholder="usuário" value={u} onChange={e=>setU(e.target.value)} />
      <input className="w-full border rounded p-2 mb-2" placeholder="Nome (opcional)" value={d} onChange={e=>setD(e.target.value)} />
      <button className="bg-coral text-white px-4 py-2 rounded-full" onClick={()=>onLogin(u,d)}>Entrar</button>
    </div>
  )
}

function Profile({username, db}){
  const user = db?.users?.[username] || {displayName:username}
  return (
    <div className="text-center">
      <div className="w-48 h-48 bg-gray-100 rounded-xl mx-auto mb-3 flex items-center justify-center text-2xl">🐱</div>
      <div className="font-bold text-lg">{user.displayName}</div>
      <div className="text-sm text-gray-500">@{user.username}</div>
      <p className="mt-2 text-sm text-gray-600">{user.about}</p>
    </div>
  )
}

function Composer({onPost}){
  const [text,setText]=useState(''); const [file,setFile]=useState(null)
  function onChange(e){
    const f = e.target.files[0]; if(!f) return;
    const reader = new FileReader(); reader.onload = (ev)=> setFile(ev.target.result); reader.readAsDataURL(f)
  }
  return (
    <div>
      <textarea className="w-full border rounded p-3 mb-2" placeholder="Compartilhe foto do seu gato..." value={text} onChange={e=>setText(e.target.value)} />
      <input type="file" accept="image/*" onChange={onChange} />
      <div className="flex justify-end mt-2">
        <button className="bg-coral text-white px-4 py-2 rounded-full" onClick={()=>{ if(!text && !file) { alert('Escreva ou anexe imagem'); return } onPost(text,file); setText(''); setFile(null)}}>Publicar</button>
      </div>
    </div>
  )
}

function Post({post, db}){
  return (
    <article className="bg-white rounded-xl shadow p-4 mb-4">
      <div className="flex gap-3">
        <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">🐾</div>
        <div className="flex-1">
          <div className="font-bold">{db?.users?.[post.author]?.displayName || post.author} <span className="text-sm text-gray-500">@{post.author}</span></div>
          <div className="text-sm text-gray-500">{new Date(post.time).toLocaleString()}</div>
          <div className="mt-2">{post.text}</div>
          {post.image ? <img src={post.image} className="mt-2 rounded-lg" alt="post" /> : null}
          <div className="flex gap-2 mt-3">
            <button className="px-3 py-1 rounded-full border">❤️ {post.likes}</button>
            <button className="px-3 py-1 rounded-full border">🐾 Meow {post.meows}</button>
            <button className="px-3 py-1 rounded-full border">💬 {post.comments?.length||0}</button>
          </div>
        </div>
      </div>
    </article>
  )
}

export default App