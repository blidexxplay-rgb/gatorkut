/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        gatorkutBg:'#fff8f2',
        coral:'#ff7a6b',
        purple:'#8b5cf6'
      }
    }
  },
  plugins: [],
}